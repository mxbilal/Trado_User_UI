> {thisisquestion} How are competition ranks determined?
>
> Highest profit % wins
>
> {thisisquestion} What is the Max daily Drawdown?
>
> 5% Max Daily Drawdown
>
> {thisisquestion} What is the max total Drawdown?
>
> 10% Max Total Drawdown
>
> {thisisquestion} Does the competition have a minimum amount of trading days?
>
> 1 Minimum Trading Days
>
> {thisisquestion} When do competitions start and stop?
>
> Competition start on the first of the month at 12:00 UTC and end on the last day of the month at 12:00 UTC
>
> {thisisquestion} When is the competition signup deadline?
>
> All participants must be registered before the competition starts
>
> {thisisquestion} How Do I receive my winnings?
>
> Someone from our live chat support ream will reach out by email with the appropriate prize
